
package com.example.travel;
import android.media.Image;

public class Details5{
    public int s9;
    public   String s1;
    public   String s2;
    public   String s3;
    public   String s4;
    public   String s5;

    public   String s8;

    Details5(int s9,String s1, String s2, String s3, String s4, String s5, String s8){
        this.s9=s9;
        this.s1=s1;
        this.s2=s2;
        this.s3=s3;
        this.s4=s4;
        this.s5=s5;
        this.s8=s8;
    }

}